﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{

    //private Rigidbody rb;
    public float speed = 10f;
   // public GameObject projectilePrefab;
    //public Transform projectileSpawn;
    //public Transform target;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("up") || Input.GetKey(KeyCode.W))
        {
            transform.Translate(new Vector3(0f, 0f, speed * Time.deltaTime));

            //print ("up or W key is held");
        }
        if (Input.GetKey("down") || Input.GetKey(KeyCode.S))
        {
            transform.Translate(new Vector3(0f, 0f, -speed * Time.deltaTime));
            
        }
        if (Input.GetKey("left") || Input.GetKey(KeyCode.A))
        {
            transform.Translate(new Vector3(-speed * Time.deltaTime, 0f, 0f));
            //print("left key A is held");
        }
        if (Input.GetKey("right") || Input.GetKey(KeyCode.D))
        {
            transform.Translate(new Vector3(speed * Time.deltaTime, 0f, 0f));
            //print("right or D key is held");
        }

 
    }
}

